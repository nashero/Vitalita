
import Card from '../components/Card';
import { PrimaryButton, SecondaryButton } from '../components/Button';

export default function Home() {
  return (
    <div className="w-full">
      <section className="w-full bg-gradient-to-br from-vitalita-primary to-vitalita-primary-light/60">
        <div className="mx-auto max-w-content px-6 py-24 flex flex-col items-start gap-6">
          <h1 className="text-vitalita-neutral-0">AI Scheduling for Blood Donation Services</h1>
          <p className="text-lg text-vitalita-neutral-0/90 max-w-prose-wide">
            Born in Italy; inspired by AVIS. Vitalita simplifies multi-channel scheduling.
          </p>
          <div className="flex gap-4 mt-4">
            <PrimaryButton>Request Early Access</PrimaryButton>
            <SecondaryButton>See How It Works</SecondaryButton>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-content px-6 py-20">
        <h2>What Vitalita Solves</h2>
        <p className="mt-4 max-w-prose-wide">
          Daily problems that donation centers face; solved with simplicity.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card title="No-shows reduced">Automated reminders reduce unpredictability.</Card>
          <Card title="Unified messaging">WhatsApp, SMS, Telegram all in one place.</Card>
          <Card title="Fewer manual tasks">AI handles repetitive scheduling steps.</Card>
        </div>
      </section>
    </div>
  );
}
