
export async function POST(request) {
  // TODO: implement auth with Supabase or other provider
  const body = await request.json();
  return Response.json({ ok: true, session: { user: body.email } });
}
