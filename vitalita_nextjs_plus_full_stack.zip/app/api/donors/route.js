
export async function GET() {
  // TODO: fetch donors from Supabase
  return Response.json({ donors: [] });
}

export async function POST(request) {
  // TODO: create new donor
  const body = await request.json();
  return Response.json({ ok: true, donor: body }, { status: 201 });
}
