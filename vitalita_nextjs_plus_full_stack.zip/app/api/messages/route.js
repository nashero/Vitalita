
export async function GET() {
  // TODO: fetch messages from Supabase
  return Response.json({ messages: [] });
}

export async function POST(request) {
  // TODO: store inbound/outbound message
  const body = await request.json();
  return Response.json({ ok: true, message: body }, { status: 201 });
}
