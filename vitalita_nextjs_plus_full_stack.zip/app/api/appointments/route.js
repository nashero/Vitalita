
export async function GET() {
  // TODO: fetch appointments from Supabase
  return Response.json({ appointments: [] });
}

export async function POST(request) {
  // TODO: create new appointment in Supabase
  const body = await request.json();
  return Response.json({ ok: true, appointment: body }, { status: 201 });
}
