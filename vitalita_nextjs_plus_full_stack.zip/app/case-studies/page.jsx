
import Card from '../../components/Card';

export default function CaseStudies() {
  return (
    <div className="mx-auto max-w-content px-6 py-20">
      <h1>Case Studies</h1>
      <p className="mt-4 max-w-prose-wide">Real impact from centers using Vitalita.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
        <Card title="31% fewer no-shows">Automated reminders and smart slot allocation.</Card>
        <Card title="54% faster response time">Unified inbox improved staff efficiency.</Card>
        <Card title="22% more repeat donors">Better communication and consistency.</Card>
        <Card title="Load balancing ">AI smoothed daily donor flow.</Card>
      </div>
    </div>
  );
}
