
import Card from '../../components/Card';

export default function Features() {
  return (
    <div className="mx-auto max-w-content px-6 py-20">
      <h1>Features</h1>
      <p className="mt-4 max-w-prose-wide">
        The full Vitalita feature set.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
        <Card title="Unified Inbox">WhatsApp, Telegram, SMS, email and voice in one view.</Card>
        <Card title="AI Smart Scheduling">Prevents double bookings, manages capacity.</Card>
        <Card title="Automated Messages">Reminders, confirmations, changes handled automatically.</Card>
      </div>
    </div>
  );
}
