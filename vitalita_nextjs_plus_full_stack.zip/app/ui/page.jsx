
import Card from "../../components/Card";
import { PrimaryButton, SecondaryButton } from "../../components/Button";
import KpiTile from "../../components/KpiTile";
import Alert from "../../components/Alert";
import InboxMock from "../../components/InboxMock";
import ScheduleMock from "../../components/ScheduleMock";
import DonorTable from "../../components/DonorTable";

export default function UiPreview() {
  return (
    <div className="mx-auto max-w-content px-6 py-16 space-y-12">
      <section>
        <h1>Vitalita UI Preview</h1>
        <p className="mt-2 text-vitalita-neutral-700">
          A quick overview of the core components used across the Vitalita interface.
        </p>
      </section>

      <section className="space-y-4">
        <h2>Buttons</h2>
        <div className="flex flex-wrap gap-4">
          <PrimaryButton>Primary Button</PrimaryButton>
          <SecondaryButton>Secondary Button</SecondaryButton>
        </div>
      </section>

      <section className="space-y-4">
        <h2>Cards & KPIs</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card title="Standard Card">
            <p>Generic content inside the card component.</p>
          </Card>
          <KpiTile label="Reduction in no-shows" value="31%" />
          <KpiTile label="Faster responses" value="54%" />
        </div>
      </section>

      <section className="space-y-4">
        <h2>Alerts</h2>
        <div className="space-y-3">
          <Alert type="success" title="Configuration saved">
            Settings updated successfully.
          </Alert>
          <Alert type="info" title="Sandbox mode">
            Demo data only; connect Supabase to enable live data.
          </Alert>
          <Alert type="warning" title="RLS not configured">
            Row-level security should be configured before production use.
          </Alert>
          <Alert type="error" title="Connection issue">
            Unable to reach the API. Check your environment variables.
          </Alert>
        </div>
      </section>

      <section className="space-y-4">
        <h2>Inbox & Schedule mocks</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <InboxMock />
          <ScheduleMock />
        </div>
      </section>

      <section className="space-y-4">
        <h2>Donor table</h2>
        <DonorTable />
      </section>
    </div>
  );
}
