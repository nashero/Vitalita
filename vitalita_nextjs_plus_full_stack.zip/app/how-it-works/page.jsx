
export default function HowItWorks() {
  return (
    <div className="mx-auto max-w-content px-6 py-20">
      <h1>How Vitalita Works</h1>
      <div className="space-y-10 mt-10">
        <div>
          <h3>1. Donor reaches out</h3>
          <p>Via WhatsApp, SMS, Telegram, email, or voice.</p>
        </div>
        <div>
          <h3>2. Vitalita suggests best slot</h3>
          <p>Uses AI + capacity + donor history.</p>
        </div>
        <div>
          <h3>3. Donor confirms</h3>
          <p>Instant confirmation and calendar update.</p>
        </div>
        <div>
          <h3>4. Staff view everything</h3>
          <p>Unified dashboard with complete visibility.</p>
        </div>
        <div>
          <h3>5. Smart follow-up</h3>
          <p>Automated reminders, instructions and updates.</p>
        </div>
      </div>
    </div>
  );
}
