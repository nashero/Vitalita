
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}","./app/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        vitalita: {
          primary:{DEFAULT:"#1D4E89",light:"#A9D2F3",dark:"#143A66"},
          accent:{DEFAULT:"#0FA27A",light:"#84D9C2"},
          neutral:{0:"#FFFFFF",100:"#F6F7F8",300:"#D4D6D9",700:"#63666A",900:"#1B1B1B"},
          success:"#0FA27A",
          warning:"#E5A400",
          error:"#C44536",
          info:"#2A6FBD",
        },
      },
      fontFamily:{sans:["IBM Plex Sans","Roboto","system-ui"]},
      boxShadow:{vitalita:"0 10px 30px rgba(0,0,0,0.04)"},
      borderRadius:{lg:"12px",xl:"20px"},
      maxWidth:{content:"1200px","prose-wide":"800px"},
    },
  },
  plugins: [],
};
