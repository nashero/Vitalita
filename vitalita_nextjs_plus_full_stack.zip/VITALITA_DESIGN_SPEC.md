
# Vitalita Design & UX Spec (Dev Handoff)

## Brand

- Palette: Azure civic-tech
- Primary: #1D4E89 (P500)
- Secondary: #A9D2F3 (P300)
- Accent: #0FA27A (A500)
- Neutrals: #FFFFFF, #F6F7F8, #D4D6D9, #63666A, #1B1B1B
- Status: success #0FA27A, warning #E5A400, error #C44536, info #2A6FBD

## Typography

- Font: IBM Plex Sans, fallback Roboto
- H1: 48–56px, weight 600
- H2: 32–36px, weight 600
- H3: 24–28px, weight 500
- Body: 16–18px, weight 400

## Layout

- Max content width: 1200px
- Grid: 12 columns
- Section vertical spacing:
  - Desktop: 80px
  - Mobile: 40px

## Key Components

- Buttons:
  - Primary: bg accent, white text, rounded-lg
  - Secondary: border primary, text primary, hover bg primary/5

- Cards:
  - bg neutral-0, border neutral-300, radius lg, shadow-vitalita

- KPI Tiles:
  - Use KpiTile component
  - Number prominently in primary-dark

- Alerts:
  - Use Alert component with type prop (success|warning|error|info).

- Layout:
  - Navbar + Footer shared in layout.jsx
  - Pages: Home, Features, How It Works, Case Studies, UI Preview

## API

- app/api/appointments: GET, POST
- app/api/donors: GET, POST
- app/api/messages: GET, POST
- app/api/auth: POST (stub)

## Data

- Schema defined in supabase_schema.sql.
- RLS must be enabled before production.

