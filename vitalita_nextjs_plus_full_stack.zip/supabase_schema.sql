
-- Vitalita Supabase schema (scheduling & donor CRM)

create table if not exists centers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  region text,
  created_at timestamptz default now()
);

create table if not exists donors (
  id uuid primary key default gen_random_uuid(),
  center_id uuid references centers(id) on delete cascade,
  full_name text not null,
  email text,
  phone text,
  preferred_channel text check (preferred_channel in ('whatsapp','sms','telegram','email','voice')),
  notes text,
  created_at timestamptz default now()
);

create table if not exists appointments (
  id uuid primary key default gen_random_uuid(),
  center_id uuid references centers(id) on delete cascade,
  donor_id uuid references donors(id) on delete set null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status text check (status in ('scheduled','completed','cancelled','no_show')) default 'scheduled',
  channel text,
  created_at timestamptz default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  center_id uuid references centers(id) on delete cascade,
  donor_id uuid references donors(id) on delete set null,
  direction text check (direction in ('inbound','outbound')) not null,
  channel text not null,
  body text not null,
  metadata jsonb,
  created_at timestamptz default now()
);

create table if not exists staff (
  id uuid primary key default gen_random_uuid(),
  center_id uuid references centers(id) on delete cascade,
  full_name text not null,
  role text,
  email text,
  created_at timestamptz default now()
);

-- Indexes
create index if not exists idx_appointments_center_time on appointments(center_id, starts_at);
create index if not exists idx_messages_center_time on messages(center_id, created_at);
create index if not exists idx_donors_center on donors(center_id);

-- NOTE: configure Row Level Security (RLS) policies in Supabase dashboard
-- so each center only sees its own data.
