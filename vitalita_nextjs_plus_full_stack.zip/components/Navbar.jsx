
import { PrimaryButton } from "./Button";

export default function Navbar() {
  return (
    <header className="w-full border-b border-vitalita-neutral-100 bg-white">
      <div className="mx-auto max-w-content px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-vitalita-primary-light" />
          <span className="text-lg font-semibold text-vitalita-primary-dark">Vitalita</span>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-vitalita-neutral-900">
          <a className="hover:text-vitalita-primary" href="#">Features</a>
          <a className="hover:text-vitalita-primary" href="#">How it works</a>
          <a className="hover:text-vitalita-primary" href="#">Case studies</a>
          <a className="hover:text-vitalita-primary" href="#">Contact</a>
          <PrimaryButton>Request Early Access</PrimaryButton>
        </nav>
      </div>
    </header>
  );
}
