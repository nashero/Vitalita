
export default function KpiTile({ label, value }) {
  return (
    <div className="bg-vitalita-neutral-100 border border-vitalita-neutral-300 rounded-lg p-6 flex flex-col gap-2">
      <span className="text-3xl md:text-4xl font-semibold text-vitalita-primary-dark">
        {value}
      </span>
      <span className="text-sm font-medium text-vitalita-neutral-700">
        {label}
      </span>
    </div>
  );
}
