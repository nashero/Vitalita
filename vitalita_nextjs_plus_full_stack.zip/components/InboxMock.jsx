
const messages = [
  { id: 1, channel: "WhatsApp", donor: "Maria Rossi", snippet: "Posso spostare la donazione di domani?", time: "09:32" },
  { id: 2, channel: "SMS", donor: "Luca Bianchi", snippet: "Confermo l'appuntamento di venerdì.", time: "08:15" },
  { id: 3, channel: "Telegram", donor: "Sara Verdi", snippet: "Vorrei prenotare per la prossima settimana.", time: "Ieri" },
];

export default function InboxMock() {
  return (
    <div className="bg-vitalita-neutral-0 border border-vitalita-neutral-300 rounded-lg shadow-vitalita overflow-hidden">
      <div className="px-4 py-3 border-b border-vitalita-neutral-300 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-vitalita-neutral-900">
          Unified inbox
        </h3>
        <span className="text-xs text-vitalita-neutral-700">Demo</span>
      </div>
      <ul className="divide-y divide-vitalita-neutral-100">
        {messages.map((m) => (
          <li key={m.id} className="px-4 py-3 flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-vitalita-neutral-700 uppercase">
                {m.channel}
              </p>
              <p className="text-sm font-semibold text-vitalita-neutral-900">
                {m.donor}
              </p>
              <p className="text-xs text-vitalita-neutral-700 line-clamp-1">
                {m.snippet}
              </p>
            </div>
            <span className="text-xs text-vitalita-neutral-700">{m.time}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
