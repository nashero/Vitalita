
export function PrimaryButton({ children }) {
  return (
    <button className="inline-flex items-center justify-center px-7 py-3 rounded-lg text-base font-semibold text-white bg-vitalita-accent hover:bg-vitalita-accent-light transition">
      {children}
    </button>
  );
}

export function SecondaryButton({ children }) {
  return (
    <button className="inline-flex items-center justify-center px-7 py-3 rounded-lg text-base font-semibold border border-vitalita-primary text-vitalita-primary hover:bg-vitalita-primary/5 transition">
      {children}
    </button>
  );
}
