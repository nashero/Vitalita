
const donors = [
  { id: 1, name: "Maria Rossi", lastDonation: "2025-10-12", channel: "WhatsApp", status: "Active" },
  { id: 2, name: "Luca Bianchi", lastDonation: "2025-09-05", channel: "SMS", status: "Active" },
  { id: 3, name: "Giulia Neri", lastDonation: "2025-07-23", channel: "Telegram", status: "Paused" },
];

export default function DonorTable() {
  return (
    <div className="bg-vitalita-neutral-0 border border-vitalita-neutral-300 rounded-lg overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-vitalita-neutral-100 text-vitalita-neutral-900">
          <tr>
            <th className="px-4 py-2 text-left">Donor</th>
            <th className="px-4 py-2 text-left">Last donation</th>
            <th className="px-4 py-2 text-left">Preferred channel</th>
            <th className="px-4 py-2 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {donors.map((d) => (
            <tr key={d.id} className="border-t border-vitalita-neutral-100">
              <td className="px-4 py-2 text-vitalita-neutral-900">{d.name}</td>
              <td className="px-4 py-2 text-vitalita-neutral-700">{d.lastDonation}</td>
              <td className="px-4 py-2 text-vitalita-neutral-700">{d.channel}</td>
              <td className="px-4 py-2 text-vitalita-neutral-700">{d.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
