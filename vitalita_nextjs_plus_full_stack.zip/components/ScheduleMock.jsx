
const slots = [
  { time: "08:30", status: "Booked", donors: 3 },
  { time: "09:30", status: "Balanced", donors: 2 },
  { time: "10:30", status: "Available", donors: 0 },
  { time: "11:30", status: "Booked", donors: 3 },
];

const statusColor = {
  Booked: "bg-vitalita-error/10 text-vitalita-error",
  Balanced: "bg-vitalita-accent/10 text-vitalita-accent",
  Available: "bg-vitalita-info/10 text-vitalita-info",
};

export default function ScheduleMock() {
  return (
    <div className="bg-vitalita-neutral-0 border border-vitalita-neutral-300 rounded-lg shadow-vitalita overflow-hidden">
      <div className="px-4 py-3 border-b border-vitalita-neutral-300 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-vitalita-neutral-900">
          Daily schedule
        </h3>
        <span className="text-xs text-vitalita-neutral-700">Demo</span>
      </div>
      <table className="w-full text-sm">
        <tbody>
          {slots.map((slot) => (
            <tr key={slot.time} className="border-b border-vitalita-neutral-100">
              <td className="px-4 py-2 text-vitalita-neutral-900">{slot.time}</td>
              <td className="px-4 py-2">
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${statusColor[slot.status]}`}>
                  {slot.status}
                </span>
              </td>
              <td className="px-4 py-2 text-right text-vitalita-neutral-700">
                {slot.donors} donors
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
