
const typeMap = {
  success: {
    border: "border-vitalita-success",
    bg: "bg-vitalita-success/10",
  },
  warning: {
    border: "border-vitalita-warning",
    bg: "bg-vitalita-warning/10",
  },
  error: {
    border: "border-vitalita-error",
    bg: "bg-vitalita-error/10",
  },
  info: {
    border: "border-vitalita-info",
    bg: "bg-vitalita-info/10",
  },
};

export default function Alert({ type = "info", title, children }) {
  const styles = typeMap[type] || typeMap.info;
  return (
    <div className={`flex items-start gap-3 rounded-lg border px-4 py-3 ${styles.border} ${styles.bg}`}>
      <div className="mt-0.5 h-5 w-5 rounded-full bg-white/70" />
      <div>
        {title && (
          <p className="text-sm font-semibold text-vitalita-neutral-900">
            {title}
          </p>
        )}
        {children && (
          <p className="text-sm text-vitalita-neutral-700">
            {children}
          </p>
        )}
      </div>
    </div>
  );
}
