
export default function Footer() {
  return (
    <footer className="w-full bg-vitalita-primary-dark text-vitalita-neutral-0 mt-16">
      <div className="mx-auto max-w-content px-6 py-12 grid grid-cols-1 md:grid-cols-4 gap-8 text-sm">
        <div>
          <h3 className="text-base font-semibold mb-3">Vitalita</h3>
          <p className="text-vitalita-neutral-0/80">
            AI scheduling and communication for blood donation services.
          </p>
        </div>
      </div>
      <div className="border-t border-vitalita-primary-light/30">
        <div className="mx-auto max-w-content px-6 py-4 text-xs text-vitalita-neutral-0/70">
          © {new Date().getFullYear()} Vitalita. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
