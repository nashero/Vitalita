
export default function Card({ title, children }) {
  return (
    <div className="bg-vitalita-neutral-0 border border-vitalita-neutral-300 rounded-lg p-6 shadow-vitalita">
      {title && <h3 className="text-xl font-medium mb-3">{title}</h3>}
      <div>{children}</div>
    </div>
  );
}
